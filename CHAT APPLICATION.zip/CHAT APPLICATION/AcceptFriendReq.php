<?php
// AcceptFriendReq.php used to accept friend request sent from another user.
session_start();
$urname = $_SESSION['name'];
$frndrequest = "";
$count;
$requser = "";
//Connect to database
$con = mysql_connect("localhost","root","");
mysql_select_db('chatserver',$con);
$result1 = mysql_query("SELECT request_user FROM request_list WHERE  accept_user = '$urname'");

$result="<table>";
$i = 0;
//Buttons to accept or ignore friend Request. 
 while($row = mysql_fetch_assoc($result1))  
{
	$_SESSION['req'][$i] = $row['request_user'];
	$requser =  $row['request_user'];
	$result .= '<tr><td>'.$row['request_user'].'</td>';
	$result .= '<td><input type="submit" class = "btn" name="'.$i.'" value="Accept"></td>';
	$result .= '<td><input type="submit" class = "btn" name="'.$i.'" value="Ignore"></td></tr>';
	$i++;
				
	break;
}
$result .= "</table>";
			
$_SESSION['result'] = $result;	

	if($_POST) {
		echo "button clicked";
		echo "<br>--------------------POST-----------------------------------<br>";
		echo "<pre>";
		var_dump($_POST);
		echo "</pre>";
		echo $_POST[0];
		//Request information wil be deleted after accepting or rejecting friend request from request_list table
		//If the log in user accepts friend request friend name will be inserted into friend_list table
		$requser = $_SESSION['req'][0];
		mysql_query("DELETE FROM request_list where request_user = '$requser' and accept_user = '$urname'");
		echo "DELETE FROM request_list where request_user = '$requser' and accept_user = '$urname'";
		
		if($_POST[0] == 'Accept'){
				mysql_query("INSERT INTO friend_list VALUES ('$requser' , '$urname')");
		}
		header("Location:". $_SERVER['PHP_SELF'], true, 303);
		exit();
		
	}	
	if(!empty($_SESSION['result'])) {
	$frndrequest = $_SESSION['result'];
	}


?>


<!DOCTYPE html>
<html>
	<head>
		<title>Chat Server</title>
		<link type="text/css" rel="stylesheet" href="MyStyle.css" />
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
		<script type="text/javascript" src="../../scripts/jquery-1.11.1.min.js"></script>
		
		<script>
		
		function acceptfrnd(){
			document.getElementById("demo").innerHTML= "<h1>Hello world</h2>";
		}
		function drawInputTable(){
			document.getElementById("demo").innerHTML= "<h1>Hello world</h2>";
		}
		$(document).ready(function() {
			 $('.btn').click(function() {
				var id = this.id;
				document.getElementById("demo").innerHTML= "<h1>click identified by javascipt.</h2>";
			});
			
			$("button").click(function(){
			$.ajax({
				url:"AcceptFriendReq.php", //the page containing php script
				type: "POST", //request type
				success:function(result){
				alert(result);
			}
			});
			});
		})
		function changeText(id) {
		id.innerHTML = "Ooops!";
		}
		
	</script>
	</head>
	<body>
	<!--Add Friend  -->
		<div id = "frndrequstdiv">
			<form name="myform" action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
				<fieldset>
				<legend align="center">Accept Friend Request</legend>
				<p id = "showreq"><?php echo $frndrequest?></p>
				
				</fieldset>
			</form>
			
		</div>		
	</body>
	
	
</html>