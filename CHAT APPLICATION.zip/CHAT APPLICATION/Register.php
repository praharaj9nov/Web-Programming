<?php
/*Register.php used to register a new user
New user  registered is inserted into user_list table
*/
if(isset($_POST['submit'])){
//Database connection
$con = mysql_connect("localhost","root","");
mysql_select_db('chatserver',$con);
$uname = $_POST['username'];
$pword = $_POST['password'];
$pword2 = $_POST['password1'];
$fullname1 = $_POST['fullname'];
$Address1 = $_POST['address'];
if($pword != $pword2){
	$message1 = "Passwords do not match";
echo "<script type='text/javascript'>alert('$message1');</script>";
}
else{
$checkexist = mysql_query("SELECT user_id FROM user_list WHERE name='$fullname1'");
if(mysql_num_rows($checkexist)){
	$message2 = "Username already exists, please select different username";
	echo "<script type='text/javascript'>alert('$message2');</script>";	
}
else{
echo " <font size='5' color='green'>You have successfully registered</font>";
mysql_query("INSERT INTO user_list (user_id, name, address,password) VALUES ('$uname','$fullname1','$Address1','$pword')");
//mysql_query("INSERT INTO online_users (user_id, name ) VALUES ('$uname','$fullname1')");
}
}
}
?>
<html>
<head>
        <title> Registration form </title>
		<link type="text/css" rel="stylesheet" href="MyStyle.css" />	
</head>
<body>
<!-- Registration form created to add a new user. After successfully registered it will call Loginform.php to login into chat-->
<div id="registrationform"> 
    <h2 size: 36px style="color:white">Sign Up</h2>
	<h3 style="color:white">It is free and always will be</h3>
		<form action="Register.php" method="post">
		    <br>
			<input type="text" name="username" placeholder="Enter User ID" id="username" /><br>
			<input type="text" name="fullname" placeholder="Enter Full Name" id="name" /><br>
			<input type="password"  name="password" placeholder="Enter Password" id="password" /><br>
			<input type="password" name="password1" placeholder="Re-enter Password" id="password1"></td><br>
			<input type="text" name="address" placeholder="Enter Address" id="address" /><br><br>
			<input type="submit" style="color:Blue"name="submit" id="Register" value="Register" />
		</form>
		<br>
		<p style="color:white">Click <a href='Loginform.php'> here </a> to log in.  </p>
	</div>
</body>
</table>
</form>
</head>
</html>
