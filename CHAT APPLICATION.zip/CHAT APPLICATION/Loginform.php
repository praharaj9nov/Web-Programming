<?php
//Loginform.php is the start of chat program.
session_start();
	$con = mysql_connect("localhost","root","");
	mysql_select_db('chatserver',$con);

	if(!isset($_SESSION['name'])){
		loginForm();
	}
	else {
		loginForm();
	}
	/* Function to login to chat application. It wi call login.php to validate if the given username password is 
	correct or not and to prevent multiple user login in same browser if the user is already logged in.
	It will call Register.php to register as a new user.
	*/
	function loginForm(){
	echo'
	<div id="loginform">
	    <div id = "graphics"> <img src="chat2.gif" alt="Hop Chat" height="150" width="150"><br>
		 <p style="color:white" "font:10">Global Chat</p>
		 </div>
	    <h1 style="color:white"> Login to your account </h1>
		<form action="Login.php" method="post">
			<input type="text" name="name" placeholder=" Enter User ID" id="name" /><br>
			<input type="password"  name="password" placeholder="Enter Password "id="password" /><br><br>
			<input type="submit" style="color:blue" name="enter" id="enter" value="Login" /><br>
			<p style="color:white">New user? <a href="Register.php">Register here to get an account</a></p><br>
		</form>
	</div>';
	}
	if(isset($_POST['enter'])){
		if($_POST['name'] != "" && $_POST['password'] != ""){
			$_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
			$urname = $_SESSION['name'];
			$password = $_SESSION['password'];
			$checkuserinfo = mysql_query("SELECT count(*) FROM user_list WHERE user_id = '$urname' AND password = '$password' ");		
			echo "SELECT count(*) FROM user_list WHERE user_id = '$urname' AND password = '$password'";
				if($checkuserinfo == 0){
					echo '<span class="error">Incorrect User name or password</span>';
					echo " Re-enter correct user name or password ";
					$_POST['name'] = "";
					$_POST['password'] != "";
					$error = 1;
				}
		}
		else{
			echo '<span class="error">Please type in a name and a password</span>';
		}
	}

?>

<!DOCTYPE html>
<html>
	<head>
		<title>Login</title>
		<link type="text/css" rel="stylesheet" href="MyStyle.css" />	
	</head>
<body>
</body>
<html>