<?php

	session_start();
		$_SESSION['name'] = $_POST['name'];           
		$username = $_POST['name']; //username inputed in login form
		$password = $_POST['password']; //password inputed in login form
		//Database connection 
		$con = mysql_connect("localhost","root","");
		mysql_select_db('chatserver',$con);
		//Check in database whether the user is already logged in or not
		$result = mysql_query("SELECT * FROM user_list WHERE user_id='$username' AND password='$password' ");
		$result1 = mysql_query("SELECT * FROM online_users WHERE user_id = (SELECT user_id FROM user_list WHERE user_id='$username' AND password = '$password' )");	
		if (mysql_num_rows($result1)) {
		  echo "<font size='5' color='green';>You are already logged in. Logout or Click <a href='Loginform.php'>here</a> to login as a different user</font>	";
		}
		else if (mysql_num_rows($result)){
			$res = mysql_fetch_array($result);
			$_SESSION['username'] = $res['user_id'];
			$urname = $res['user_id'];
			$date = date("Y-m-d H:i:s");
			//If username and password is correct and user has not logged in before then allow going to chat window
			//Insert login details in online_users table
			mysql_query("INSERT INTO online_users (user_id,login_time,status ) VALUES ('$urname', '$date', 'on')");
			echo "<font size='5' color='green';>You are now login. Click <a href='Chatwindow.php'>here</a> to go back to main chat window</font> ";
			echo mysql_error();
								}
		else {
			//Check in database whether the username and password inputed by user is correct or not as done ruring registration
			echo "<font size='4' color='red';>Incorrect User Name and password. To Re-enter User Name and Password click <a href='Loginform.php'>here</a><br></font>  ";
			echo "<font size='4' color='green';>You may register as new user by clicking <a href='Register.php'>here</a><br><font>";
}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Login</title>
	</head>
<body bgcolor="#A9BCF5">
</body>
<html>