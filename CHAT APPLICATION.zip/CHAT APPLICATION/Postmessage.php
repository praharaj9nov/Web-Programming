<?php
/*postmessage.php used to store group chat messages into chat_history table. Initially the group chat will be enabled
User can go to private chat by clicking on a particular friend on friend list list on the right side table of chat window
Private chat will be stored in chat_history_private table
*/
session_start();
if(isset($_SESSION['name'])){
   $text = $_POST['text'];
//database connection
   $con = mysql_connect("localhost","root","");
	mysql_select_db('chatserver',$con);
	
	$urname = $_SESSION['name'];
	$msg = stripslashes(htmlspecialchars($text));	
	$date = date("Y-m-d H:i:s");
	
	if($_SESSION['private'] == '0')$query = "INSERT INTO chat_history(user_id, message,time) VALUES ('$urname', '$msg','$date')";
	else {
		$frnd = $_SESSION['friend_name'];
		$query = "INSERT INTO chat_history_private VALUES ('$urname', '$frnd','$msg','$date')";
	}
	
	mysql_query($query);
	

}
?>
