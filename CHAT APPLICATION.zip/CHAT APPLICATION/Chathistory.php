
<?php

session_start();
$user=$_SESSION['name'];
  $con = mysql_connect("localhost","root","");
	mysql_select_db('chatserver',$con);

	file_put_contents("Templog.html","");
	$fp1 = fopen("Templog.html", 'w');
	
	if($_SESSION['private'] == '0'){
		$query = "select user_id, message, time from chat_history";
	
		$result1 = mysql_query($query);
if (mysql_num_rows($result1) > 0) 
{
         while($row = mysql_fetch_assoc($result1))  
        {
		$m = "<i>" . $row["time"].": "."</i>" ."<b>". $row["user_id"]."</b>".": " .$row["message"].  "<br>";//added
		$emo = array(":)", ":D", ":P", "B-)", "\:D/", ":((" ); 
        $img = array("<img src='emotions1.png' height='20' width='20' alt='happy' />",
        "<img src='emotions2.png' height='20' width='20' alt='lol' />",
        "<img src='emotions3.png' height='20' width='20' alt='tongue out' />",
        "<img src='emotions4.png' height='20' width='20' alt='cool' />",
		"<img src='emotions5.png' height='20' width='20' alt='Too good' />",
		"<img src='emotions6.png' height='20' width='20' alt='sad' />"
		);
        $new_str = str_replace($emo, $img, $m);
        echo $new_str;
        //echo  "<i>" . $row["time"].": "."</i>" ."<b>". $row["user_id"]."</b>".": " .$row["message"].  "<br>"; 
        fwrite($fp1, "<div class='msgln'><i>". $row['time']. ":" . $row['user_id'] . ": " . $row["message"] ."</i><br></div>");
        }
} 
	}
else 
{
 
		$frnd = $_SESSION['friend_name'];
		$query = "select * from chat_history_private where (user_1 = '$user' and user_2 = '$frnd') 
		or (user_2 = '$user' and user_1 = '$frnd')";
	
		$result1 = mysql_query($query);
if (mysql_num_rows($result1) > 0) 
{
         while($row = mysql_fetch_assoc($result1))  
        {
		$m = "<i>" . $row["time"].": "."</i>" ."<b>". $row["user_1"]."</b>".": " .$row["message"].  "<br>";//added
		$emo = array(":)", ":D", ":P", "B-)", "\:D/", ":((" ); 
        $img = array("<img src='emotions1.png' height='20' width='20' alt='happy' />",
        "<img src='emotions2.png' height='20' width='20' alt='lol' />",
        "<img src='emotions3.png' height='20' width='20' alt='tongue out' />",
        "<img src='emotions4.png' height='20' width='20' alt='cool' />",
		"<img src='emotions5.png' height='20' width='20' alt='Too good' />",
		"<img src='emotions6.png' height='20' width='20' alt='sad' />"
		);
        $new_str = str_replace($emo, $img, $m);
        echo $new_str;
        //echo  "<i>" . $row["time"].": "."</i>" ."<b>". $row["user_id"]."</b>".": " .$row["message"].  "<br>"; 
        fwrite($fp1, "<div class='msgln'><i>". $row['time']. ":" . $row['user_1'] . ": " . $row["message"] ."</i><br></div>");
        }
} 
	
 
}

fclose($fp1);		
?>