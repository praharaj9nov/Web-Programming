
<?php
session_start();

$friend_list = "";
$urname = $_SESSION['name'];

if(!isset($_GET['friend'])){
	$_SESSION['private'] = '0';
}
else{
	$_SESSION['friend_name']= $_GET['friend'];
	$_SESSION['private'] = $_GET['private'];
}
//Database connection 
	$con = mysql_connect("localhost","root","");
	mysql_select_db('chatserver',$con);
// Chats  will be inserted to chat_history table and any user when logs out the user information will be deleted from online_users table
	if(isset($_GET['logout'])){
	
		
		$msg = "has left the chat session.";	
		$date = date("Y-m-d H:i:s");	
		mysql_query("INSERT INTO chat_history(user_id, message,time) VALUES ('$urname', '$msg','$date')");
		mysql_query("DELETE  FROM online_users where user_id = '$urname'");
		session_destroy();
		header("Location: Loginform.php"); //Redirect the user
	}

?>


<!DOCTYPE html>
<html>
	<head>
		<title>chat window</title>
		<link type="text/css" rel="stylesheet" href="MyStyle.css" />
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>	
	</head>

<?php
	/*if(!isset($_SESSION['name'])){
		loginForm();
	
	} 
	else */
	if(isset($_SESSION['name'])){
?>
<!-- Chat window  -->
	<div id="wrapper">
		<div id="menu">
			<p class="welcome" style="color:white">Welcome, <b><?php echo $_SESSION['name']; ?><?php echo "<font face='Times Roman' size='2'>";?></b></p>
			<p class="logout" style="color:white"><a id="exit" href="#">Log Out</a></p>
			<div style="clear:both">
		</div>
	</div>

	<div id="chatbox"></div>
	

		<form name="message" action="">
			<input name="usermsg" type="text" id="usermsg" size="63" />
			<input name="submitmsg" type="submit"  id="submitmsg" value="Send" />
		</form>
	</div>
		<div id= "friends"> 
	<p><center>Friends</center> </p>
	</div>
	<div id="friendList">
	<?php 
				$friend_list= "";
				$res= mysql_query("(SELECT user1 FROM friend_list where user2 = '$urname')
						union
						(select user2 from friend_list where user1 = '$urname')");
								while($row = mysql_fetch_assoc($res)){
				$friend_list .= '<a class="button" href="chatwindow.php?private=1&friend='.$row['user1'].'" >'. $row['user1'].' </a><br>';
				//$friend_list .= "<div class='msgln'><b>". $row['user1']. "<br></div>";		
				}
				
				echo $friend_list;
	?>
	</div>
	<div id= "OnlineUsers"> <!-- Division to display list of online users -->
	<p><center> Online Users</center> </p>
	</div>
	<div id="usersOnLine">
	<?php       // The below query will fetch list of online users from database
				$availableonline = "";
				$result2 = mysql_query("SELECT user_id, status FROM online_users ORDER BY user_id");
				while($row = mysql_fetch_assoc($result2)){
				$availableonline .= "<div class='msgln'><b>". $row['user_id']. "<br></div>";				}
				
				echo $availableonline;
	?></div>
	<!-- Division to add friend  and send friend request. On clicking link  will call AcceptFriendReq.php and SendFriendReq.php -->
	<div id = "AddFriendSendRequest">
	<a class="button" href="SendFriendReq.php" target="_blank" >Add New Friend</a><br>
	<a class="button" href="AcceptFriendReq.php" target="_blank">New Friend Requests</a>
	</div>
	<!--It will call chathistory.php to loadand refresh chat logs every 1000 ms -->
	<script type="text/javascript">

		$(document).ready(function(){
			 function loadlink(){
             $('#chatbox').load('Chathistory.php',function () {
             $(this).unwrap();
             });
			 }
  
			$("#exit").click(function(){
				var exit = confirm("Are you sure you want to end the session?");
				if(exit==true){window.location = 'Chatwindow.php?logout=true';}
		});
		

		$("#submitmsg").click(function(){
			var clientmsg = $("#usermsg").val();
			$.post("Postmessage.php", {text: clientmsg});
			$("#usermsg").attr("value", "");
			return false;
		});
setInterval(function(){loadlink() }, 1000);
		});
     
	</script>
<?php
	}
?>

	</body>
</html>
