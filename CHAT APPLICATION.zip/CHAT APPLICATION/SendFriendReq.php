<?php
//SendFriendReq.php used to add a new friend by sending a friend request to another user.
session_start();
$errorMessage = $sendrequest = $frndname = "";
$output_message = "";
$urname = $_SESSION['name'];
$error = 0;



if($_POST) {
	//if nothing type dont let insert
	$sendrequest =  $_POST['sendrequest'];
	
	
	if(!$error) {
		// if there no error, do database connection here
       $con = mysql_connect("localhost","root","");
	   mysql_select_db('chatserver',$con);		
		//Insert sender and reciever information in request_list table
		mysql_query("INSERT INTO request_list VALUES ('$urname','$sendrequest')");		
		
		echo '<script language="javascript">';
		echo 'alert("Request send successfully!")';
		echo '</script>';
		
	}
	else // pretend to have error, then create session info, and redirect 
	{	   
		echo '<script language="javascript">';
		echo 'alert("Error! Try again")';
		echo '</script>';
   		header("Location:". $_SERVER['PHP_SELF'], true, 303);
   		exit();
	}	
} 
	
?>


<!DOCTYPE html>
<html>
	<head>
		<title>Chat Server</title>
		<link type="text/css" rel="stylesheet" href="MyStyle.css" />
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
	</head>
	<body>
	<!--Form to send friend request by typing person's name in input fiels -->
	<div id="request">
	<br/>
	<p><b>Type the username and send request</p>
	</br>
		<div id = "searchfrnddiv" >
			<form name="myform" action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
				<fieldset>
				<legend align="center" >Send Friend Request</legend>
				<input type="text" id="sendrequest" name="sendrequest" value="<?= $sendrequest?>" placeholder="Type user name">
				<span id="errorclass"><?=$errorMessage; ?></span>
				<input type="submit" name="requestbutton" value="Send Request">
				</fieldset>
			</form>
			<br/><br/>
			<br/>
			
		</div>
	</div>	
	
	</body>
</html>